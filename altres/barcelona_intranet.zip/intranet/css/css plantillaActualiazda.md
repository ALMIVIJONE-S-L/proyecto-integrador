*{
    margin: 0%;
    padding: 0%;
}
h1 {
    color: blue;
    font-weight: bolder;
    font-style: italic;
    text-align: center;
}

footer {
    padding: 10px;
    color: #fff;
}
